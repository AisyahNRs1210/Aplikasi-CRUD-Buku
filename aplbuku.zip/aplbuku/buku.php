<?php
// membuat instance
$dataBuku=NEW Buku;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<h2>Daftar Buku</h2>';
$html .='<p>Berikut ini Daftar Buku di Perpustakaan SMKN 2 Kuningan</p>';
$html .='<table border="1" width="100%">
<thead>
<th>No.</th>
<th>Id Buku</th>
    <th>ISBN</th>
    <th>Judul Buku</th>
    <th>Pengarang</th>
    <th>Penerbit</th>
    <th>Tipe Buku</th>
    <th>Tebal Buku</th>
    <th>Tahun Terbit</th>
<th>Aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $dataBuku->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisBuku){
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barisBuku->id_buku.'</td>
<td>'.$barisBuku->ISBN.'</td>
<td>'.$barisBuku->judul_buku.'</td>
<td>'.$barisBuku->pengarang.'</td>
<td>'.$barisBuku->penerbit.'</td>
<td>'.$barisBuku->tipe_buku.'</td>
<td>'.$barisBuku->tebal_buku.'</td>
<td>'.$barisBuku->tanggal_terbit.'</td>

<div class="link">
<td>
<a class="aksi" href="index.php?file=buku&aksi=edit&idbuku='.$barisBuku->id_buku.'">Edit</a>
<a class="aksi" href="index.php?file=buku&aksi=hapus&idbuku='.$barisBuku->id_buku.'">Hapus</a>
</td>
</div>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan form </p>';
$html .='<form method="POST"
action="index.php?file=buku&aksi=simpan">';
$html .='<p>ID Buku<br/>';
    $html .='<input type="text" name="txtid" placeholder="Masukkan ID buku" autofocus/></p>';

    $html .='<p>ISBN<br/>';
    $html .='<input type="text" name="txtisbn" placeholder="Masukkan ISBN" size="30" required/></p>';

    $html .='<p>Judul Buku<br/>';
    $html .='<input type="text" name="txtjudul" placeholder="Masukkan judul buku" size="30" required/></p>';

    $html .='<p>Pengarang<br/>';
    $html .='<input type="text" name="txtpengarang" placeholder="Masukkan nama pengarang buku ini" size="30" required/></p>';

    $html .='<p>Penerbit</p>';
    $html .='<input type="text" name="txtpenerbit" placeholder="Masukkan nama penerbit" size="30" required/></p>';

    $html .='<p>Tipe Buku<br/>';
    $html .='<input type="text" name="tipe" placeholder="Masukkan Tipe Buku" size="30" required/></p>';

    $html .='<p>Tebal Buku</p>';
    $html .='<input type="text" name="txthalaman" placeholder="Masukkan Jumlah halaman buku" size="30" required/></p>';

    $html .='<p>Tanggal Terbit</p>';
    $html .='<input type="date" name="txtTanggal" required/></p>';

    $html .='<p><input type="submit" name="tombolSimpan" value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
    'id_buku'=>$_POST['txtid'],
    'ISBN'=>$_POST['txtisbn'],
    'judul_buku'=>$_POST['txtjudul'],
    'pengarang'=>$_POST['txtpengarang'],
    'penerbit'=>$_POST['txtpenerbit'],
    'tipe_buku'=>$_POST['tipe'],
    'tebal_buku'=>$_POST['txthalaman'],
    'tanggal_terbit'=>$_POST['txtTanggal']
);
// simpan siswa dengan menjalankan method simpan

// $dataBuku ubah jadi $dataBuku, dan $siswa ubah jadi $buku
$dataBuku->simpan($data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=buku&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data siswa
$siswa=$dataBuku->detail($_GET['idbuku']);
    $html =null;
    $html .='<h3>Form Tambah</h3>';
    $html .='<p>Silahkan masukan form </p>';
    $html .='<form method="POST" action="index.php?file=buku&aksi=update">';

    $html .='<p>ID Buku<br/>';
    $html .='<input type="text" name="txtid" value="'.$siswa->id_buku.'" placeholder="Masukan ID Buku" readonly/></p>';

    $html .='<p>ISBN<br/>';
    $html .='<input type="text" name="txtisbn" value="'.$siswa->ISBN.'" placeholder="Masukan ISBN" size="30" required autofocus/></p>';

    $html .='<p>Judul buku<br/>';
    $html .='<input type="text" name="txtjudul" value="'.$siswa->judul_buku.'" placeholder="Masukan Judul Buku" size="30" required/></p>';

    $html .='<p>Pengarang<br/>';
    $html .='<input type="text" name="txtpengarang" value="'.$siswa->pengarang.'" placeholder="Masukan Nama Pengarang" size="30" required/></p>';

    $html .='<p>Penerbit<br/>';
    $html .='<input type="text" name="txtpenerbit" value="'.$siswa->penerbit.'" placeholder="Masukan Nama Penerbit" size="30" required/></p>';

    $html .='<p>Tipe Buku<br/>';
    $html .='<input type="text" name="tipe" value="'.$siswa->tipe_buku.'" placeholder="Masukan Tipe Buku" size="30" required/></p>';

    $html .='<p>Tebal buku<br/>';
    $html .='<input type="text" name="txthalaman" value="'.$siswa->tebal_buku.'" placeholder="Masukan Jumlah Halaman" size="30" required/></p>';

    $html .='<p>Tanggal Terbit<br/>';
    $html .='<input type="date" name="txtTanggal" value="'.$siswa->tanggal_terbit.'" placeholder="Masukan Tanggal Buku Terbit" size="30" required/></p>';

    $html .='<p><input type="submit" name="tombolSimpan" value="Simpan"/></p>';
    $html .='</form>';
    echo $html;
    }
    // aksi tambah data
    else if ($_GET['aksi']=='update') {
    $data=array(
        'ISBN'=>$_POST['txtisbn'],
        'judul_buku'=>$_POST['txtjudul'],
        'pengarang'=>$_POST['txtpengarang'],
        'penerbit'=>$_POST['txtpenerbit'],
        'tipe_buku'=>$_POST['tipe'],
        'tebal_buku'=>$_POST['txthalaman'],
        'tanggal_terbit'=>$_POST['txtTanggal']
);
$dataBuku->update($_POST['txtid'],$data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=buku&aksi=tampil">';

}
// aksi tambah data
else if ($_GET['aksi']=='hapus') {
$dataBuku->hapus($_GET['idbuku']);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=buku&aksi=tampil">';
}
// aksi tidak terdaftar
else {
echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
}
?>