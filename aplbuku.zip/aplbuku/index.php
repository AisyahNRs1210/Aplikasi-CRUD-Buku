<!DOCTYPE html>
<html lang="en">
<head>
<title>Data Buku Perpustakaan</title>
<link rel="stylesheet" href="css/style.css"/>
</head>
<body>
<?php
include('class/Database.php');
include('class/Buku.php');
?>
<h1 class="judulAwal">Aplikasi Data Buku Perpustakaan SMKN 2 Kuningan</h1>
<hr/>
<nav>
<ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="index.php?file=buku&aksi=tampil">Data Buku</a></li>
            <li><a href="index.php?file=buku&aksi=tambah">Tambah Data Buku</a></li>
        </ul>
</nav>

<hr/>
<?php
if(isset($_GET['file'])){
include($_GET['file'].'.php');
} else {
echo '<h1 align="center">Selamat Datang</h1>';
echo '<p align="center"> Website Ini Berisi Data Buku yang ada di perpustakaan SMKN 2 Kuningan';
}
?>
</body>
</html>